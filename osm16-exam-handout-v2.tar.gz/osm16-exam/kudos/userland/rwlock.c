#include "rwlock.h"

rwlock_t rwlock_create() {
  // FIXME: Implement.
  return -1;
}

int rwlock_rlock_acquire(rwlock_t rwlock) {
  // FIXME: Implement.
  rwlock = rwlock;
  return -1;
}

int rwlock_wlock_acquire(rwlock_t rwlock) {
  // FIXME: Implement.
  rwlock = rwlock;
  return -1;
}

int rwlock_rlock_release(rwlock_t rwlock) {
  // FIXME: Implement.
  rwlock = rwlock;
  return -1;
}

int rwlock_wlock_release(rwlock_t rwlock) {
  // FIXME: Implmenet.
  rwlock = rwlock;
  return -1;
}

int rwlock_destroy(rwlock_t rwlock) {
  // FIXME: Implement.
  rwlock = rwlock;
  return -1;
}
