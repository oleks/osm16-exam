/*
 * Timer handling
 */

#ifndef DRIVERS_TIMER_H
#define DRIVERS_TIMER_H

#include "lib/types.h"

void timer_set_ticks(uint32_t ticks);

#endif /* DRIVERS_POLLTTY_H */
