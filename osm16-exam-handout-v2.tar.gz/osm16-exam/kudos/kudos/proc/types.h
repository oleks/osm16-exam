#ifndef KUDOS_PROC_TYPES_H
#define KUDOS_PROC_TYPES_H

#include <types.h>

typedef uint64_t mutex_t;
typedef uint32_t cond_t;

#endif /* KUDOS_PROC_TYPES_H */
